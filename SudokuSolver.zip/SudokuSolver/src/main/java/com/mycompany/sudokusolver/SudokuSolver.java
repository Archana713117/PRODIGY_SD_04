
package com.mycompany.sudokusolver;

public class SudokuSolver {
    // Size of the Sudoku grid
    private static final int GRID_SIZE = 9;

    public static void main(String[] args) {
      
        // Example Sudoku puzzle (0 represents an empty cell)
        int[][] board = {
                {5, 3, 0, 0, 7, 0, 0, 0, 0},
                {6, 0, 0, 1, 9, 5, 0, 0, 0},
                {0, 9, 8, 0, 0, 0, 0, 6, 0},
                {8, 0, 0, 0, 6, 0, 0, 0, 3},
                {4, 0, 0, 8, 0, 3, 0, 0, 1},
                {7, 0, 0, 0, 2, 0, 0, 0, 6},
                {0, 6, 0, 0, 0, 0, 2, 8, 0},
                {0, 0, 0, 4, 1, 9, 0, 0, 5},
                {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };

        if (solveBoard(board)) {
            System.out.println("Sudoku puzzle solved successfully:");
            printBoard(board);
        } else {
            System.out.println("No solution exists for this Sudoku puzzle.");
        }
    }

    // Function to solve the Sudoku board using backtracking
    public static boolean solveBoard(int[][] board) {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                // If the current cell is empty
                if (board[row][col] == 0) {
                    // Try all possible numbers from 1 to 9
                    for (int num = 1; num <= 9; num++) {
                        if (isValidPlacement(board, num, row, col)) {
                            // Place the number
                            board[row][col] = num;

                            // Recursively try to solve the rest of the board
                            if (solveBoard(board)) {
                                return true;
                            } else {
                                // Undo the placement if it leads to an invalid state
                                board[row][col] = 0;
                            }
                        }
                    }
                    // If no number is valid, return false (trigger backtracking)
                    return false;
                }
            }
        }
        // If no empty cells remain, the board is solved
        return true;
    }

    // Function to check if placing a number in a given cell is valid
    public static boolean isValidPlacement(int[][] board, int num, int row, int col) {
        // Check the row
        for (int i = 0; i < GRID_SIZE; i++) {
            if (board[row][i] == num) {
                return false;
            }
        }

        // Check the column
        for (int i = 0; i < GRID_SIZE; i++) {
            if (board[i][col] == num) {
                return false;
            }
        }

        // Check the 3x3 sub-grid
        int subGridRow = row - row % 3;
        int subGridCol = col - col % 3;
        for (int i = subGridRow; i < subGridRow + 3; i++) {
            for (int j = subGridCol; j < subGridCol + 3; j++) {
                if (board[i][j] == num) {
                    return false;
                }
            }
        }

        return true;
    }

    // Function to print the Sudoku board
    public static void printBoard(int[][] board) {
        for (int row = 0; row < GRID_SIZE; row++) {
            if (row % 3 == 0 && row != 0) {
                System.out.println("-----------");
            }
            for (int col = 0; col < GRID_SIZE; col++) {
                if (col % 3 == 0 && col != 0) {
                    System.out.print("|");
                }
                System.out.print(board[row][col] == 0 ? "." : board[row][col]);
            }
            System.out.println();
        }
    }
}
    

